﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOLID_Fundamentals.Bank.Interfaces
{
    public interface IBankAccount
    {
        decimal Balance { get; }
        void Deposit(decimal amount);
    }
}
